import { GET_USERS } from "../constants/action-types";

export function addArticle(payload) {
  return { type: GET_USERS, payload };
}